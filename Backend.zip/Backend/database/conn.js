//connect MongoDB to server
const mongoose= require("mongoose");

mongoose.connect("mongodb://127.0.0.1:27017/MiniProject").then(() => console.log("Connected To DB")).catch((err) => console.log("Some error"));
